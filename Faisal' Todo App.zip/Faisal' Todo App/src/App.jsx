import React, { useState } from "react";
import Input from "./Component/Input";
import List from "./Component/List";
import "./App.css";

export default function App() {
  const [todos, setTodos] = useState([]);
  const [editData, setEditData] = useState({ index: "", value: "" });

  const AddTodo = (value) => {
    setTodos([...todos, value]);
  };

  const DeleteTodo = (index) => {
    setTodos(todos.filter((_, i) => i !== index));
  };

  const EditTodo = (index, value) => {
    setEditData({ index, value });
  };

  const UpdateTodo = (index, value) => {
    const updated = todos.map((item, i) => (i === index ? value : item));
    setTodos(updated);
    setEditData({ index: "", value: "" }); // clear after updating
  };

  return (
    <div className="container">
      <h1>🧾 Todo List</h1>
      <Input AddTodo={AddTodo} editData={editData} UpdateTodo={UpdateTodo} />
      <List todos={todos} DeleteTodo={DeleteTodo} EditTodo={EditTodo} />
    </div>
  );
}
