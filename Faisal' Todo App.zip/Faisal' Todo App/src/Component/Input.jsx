import React, { useEffect, useState } from "react";

export default function Input({ AddTodo, editData, UpdateTodo }) {
  const [todo, setTodo] = useState("");
  const [error, setError] = useState(false);

  const InputHandler = (event) => {
    const value = event.target.value;
    setTodo(value);
    setError(value.length === 0);
  };

  const submit = (event) => {
    event.preventDefault();

    if (todo.trim().length === 0) {
      setError(true);
      return;
    }

    if (editData.index !== "") {
      UpdateTodo(editData.index, todo);
    } else {
      AddTodo(todo);
    }

    setTodo("");
  };

  useEffect(() => {
    if (editData.value) setTodo(editData.value);
  }, [editData.value]);

  return (
    <form className="todo-input" onSubmit={submit}>
      <input
        type="text"
        value={todo}
        placeholder="Enter your todo..."
        onChange={InputHandler}
      />
      <button type="submit">
        {editData.index !== "" ? "Update" : "Add"}
      </button>
      {error && <p className="text-danger">⚠️ Please enter a todo</p>}
    </form>
  );
}
