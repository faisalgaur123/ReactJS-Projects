import React from "react";
import { FaEdit, FaTrash } from "react-icons/fa";

export default function List({ todos, DeleteTodo, EditTodo }) {
  return (
    <ul className="todo-list">
      {todos.length === 0 ? (
        <p className="empty">No todos yet — add something cool ✨</p>
      ) : (
        todos.map((todo, index) => (
          <li key={index} className="todo-item">
            <span className="todo-text">{todo}</span>
            <div className="btn-group">
              <button
                className="btn btn-edit"
                onClick={() => EditTodo(index, todo)}
              >
                <FaEdit />
              </button>
              <button
                className="btn btn-delete"
                onClick={() => DeleteTodo(index)}
              >
                <FaTrash />
              </button>
            </div>
          </li>
        ))
      )}
    </ul>
  );
}
